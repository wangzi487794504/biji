#### Map类

* 存储一对一对数据(key-value)

* HashMap:主要实现类1.2时代，线程不安全，执行效率高，可以添加null的key和value，底层也是数组+单向链表+红黑树存储

  ```java
      public void test1(){
          Map map=new HashMap();
          map.put(null, null);
      }
  {null=null}
  ```

  * LinkedHashMap:HashMap的子类，在原基础上，增加了一对双向链表，用于记录添加元素的先后顺序，便于遍历

    ```java
    @Test
        public void test1(){
            Map map=new LinkedHashMap();
            map.put("Tom", 23);
            map.put("BB", 23);
            map.put("CC", 23);
            //顺序和添加的顺序一样，因为有双向链表记录
            System.out.println(map);
        }
    ```

    

* Hashtable：古老实现类1.0时代。线程安全，执行效率低，不可以添加null的key或value(一个是null都不行)，存储是数组+单向链表存储

  * 子类：Properties:存储的key-value都是String类型，常用来处理属性文件

* TreeMap:底层使用红黑树，就是排序二叉树，可以按照key-value中的ke元素指定属性的大小进行遍历，一是自然排序，而是定制排序



###### HashMap

* key是不相同也无序，和set一样

* value可以重复，也是无序，它的存放位置取决于key

  <img src="Map%E7%B1%BB.assets/1691037128675.png" alt="1691037128675" style="zoom:80%;" />

* key和value组成了一个整体叫Entry，因为key不一样，所以Entry也不一样好，所以Entry是一个Set，所以key所在类要重写equals和hashCode方法



######Map常用方法

* 增put(key,value)  删 remove(key) return value 改 put(key,value)  就是覆盖putAll  查  get(key)，长度 size()，遍历  遍历key用keySet，返回一个Set，遍历value用values()返回是Collection  遍历entry用entrySet,返回是Set    **没有插入，因为根本没有有序**

* 接口里面可以声明接口

  ```java
  package Common;
  
  import org.junit.Test;
  import java.util.*;
  
  public class test1 {
      @Test
      public void test1(){
          HashMap map=new HashMap();
          map.put("Tom", 23);
          map.put("BB", 22);
          map.put("CC", 24);
          map.put(67, 24);
          map.put(new Person("wang", 18), 25);
          //顺序和添加的顺序一样，因为有双向链表记录
          System.out.println(map);
          //长度
          System.out.println(map.size());
          //移除
          int value= (int) map.remove("Tom");//返回是Object
          System.out.println(value);
          //修改
          map.put("BB", 23);
          System.out.println(map);
          //查询
          Object bb = map.get("BB");
          System.out.println(bb);
          //遍历
          Set keySet = map.keySet();
          for (Object obj:keySet
               ) {
              System.out.println(obj);
          }
          Collection values = map.values();
          Iterator iterator = values.iterator();
          while (iterator.hasNext()){
              System.out.println(iterator.next());
          }
          Set entrySet = map.entrySet();
          for (Object obj:entrySet
               ) {
              System.out.println((Map.Entry)obj);
          }
      }
  }
  class Person implements Comparable{
      private String name;
      private int age;
  
      public Person(String name, int age) {
          this.name = name;
          this.age = age;
      }
  
      public String getName() {
          return name;
      }
  
      public int getAge() {
          return age;
      }
  
      public void setName(String name) {
          this.name = name;
      }
  
      public void setAge(int age) {
          this.age = age;
      }
  
      @Override
      public String toString() {
          return "Person{" +
                  "name='" + name + '\'' +
                  ", age=" + age +
                  '}';
      }
  
      @Override
      public boolean equals(Object o) {
          System.out.println("equals方法");
          if (this == o) return true;
          if (o == null || getClass() != o.getClass()) return false;
          Person person = (Person) o;
          return age == person.age &&
                  Objects.equals(name, person.name);
      }
  
      @Override
      public int hashCode() {
          return Objects.hash(name, age);
      }
  
      @Override
      public int compareTo(Object o) {
          if (this==o){
              return 0;
          }
          if (o instanceof Person){
              Person person= (Person) o;
              return this.age-person.age;
          }
          throw  new RuntimeException("类型不匹配");
      }
  }
  {BB=22, CC=24, Tom=23, 67=24, Person{name='wang', age=18}=25}
  5
  23
  {BB=23, CC=24, 67=24, Person{name='wang', age=18}=25}
  23
  BB
  CC
  67
  Person{name='wang', age=18}
  23
  24
  24
  25
  BB=23
  CC=24
  67=24
  Person{name='wang', age=18}=25
  ```

  

###### TreeMap

* 底层是红黑树

* 可以按照key-value大小进行排序

* 使用自然排序或定制排序

  ```java
   @Test
      public void test1(){
          TreeMap treeMap=new TreeMap();
          treeMap.put("AA", 15);
          treeMap.put("CC", 14);
          treeMap.put("BB", 16);
          Set entrySet = treeMap.entrySet();
          //会按key排序
          for (Object entry:entrySet
               ) {
              System.out.println(entry);
          }
      }
  AA=15
  BB=16
  CC=14
  ```

  * 要求添加的key是同一个类型
  
    ```java
    
    public class test1 {
        @Test
        public void test1(){
            TreeMap treeMap=new TreeMap();
            Person person=new Person("AA", 18);
            Person person1=new Person("Jach", 19);
            Person person2=new Person("Tom", 19);//年龄一样了，这个进不去
            Person person3=new Person("Jerry", 17);
            treeMap.put(person, 15);
            treeMap.put(person1, 14);
            treeMap.put(person2, 16);
            treeMap.put(person3, 16);
            Set entrySet = treeMap.entrySet();
            //会按key排序
            for (Object entry:entrySet
                 ) {
                System.out.println(entry);
            }
            System.out.println(treeMap.containsKey(new Person("sss", 18)));//true
        }
    }
    class Person implements Comparable{
        private String name;
        private int age;
    
        public Person(String name, int age) {
            this.name = name;
            this.age = age;
        }
    
        public String getName() {
            return name;
        }
    
        public int getAge() {
            return age;
        }
    
        public void setName(String name) {
            this.name = name;
        }
    
        public void setAge(int age) {
            this.age = age;
        }
    
        @Override
        public String toString() {
            return "Person{" +
                    "name='" + name + '\'' +
                    ", age=" + age +
                    '}';
        }
    
        @Override
        public boolean equals(Object o) {
            System.out.println("equals方法");
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Person person = (Person) o;
            return age == person.age &&
                    Objects.equals(name, person.name);
        }
    
        @Override
        public int hashCode() {
            return Objects.hash(name, age);
        }
        //只比较年龄
        @Override
        public int compareTo(Object o) {
            if (this==o){
                return 0;
            }
            if (o instanceof Person){
                Person person= (Person) o;
                return this.age-person.age;
            }
            throw  new RuntimeException("类型不匹配");
        }
        //姓名和年龄都比较
    //    @Override
    //    public int compareTo(Object o) {
    //        if (this==o){
    //            return 0;
    //        }
    //        if (o instanceof Person){
    //            Person person= (Person) o;
    //            int value= this.age-person.age;
    //            if (value!=0){
    //                return value;
    //            }
    //            return -this.name.compareTo(person.name);
    //        }
    //        throw  new RuntimeException("类型不匹配");
    //    }
    }
    ```
  
    

* 定制排序

  ```java
  public class test1 {
     
      @Test
      public void test1(){
          Comparator comparator=new Comparator() {
              @Override
              public int compare(Object o1, Object o2) {
                  if (o1 instanceof  Person && o2 instanceof Person){
                      Person person= (Person) o1;
                      Person  person1= (Person) o2;
                      int value=person.getName().compareTo(person1.getName());
                      if (value!=0){
                          return value;
                      }
                      return  person.getAge()-person1.getAge();
                  }
                  throw new RuntimeException("类型不匹配");
              }
          };
          TreeMap treeMap=new TreeMap(comparator);
          Person person=new Person("AA", 18);
          Person person1=new Person("Jach", 19);
          Person person2=new Person("Tom", 19);//年龄一样了，这个进不去
          Person person3=new Person("Jerry", 17);
          treeMap.put(person, 15);
          treeMap.put(person1, 14);
          treeMap.put(person2, 16);
          treeMap.put(person3, 16);
          Set entrySet = treeMap.entrySet();
          //会按key排序
          for (Object entry:entrySet
               ) {
              System.out.println(entry);
          }
          System.out.println(treeMap.containsKey(new Person("sss", 18)));//true
      }
  }
  class Person implements Comparable{
      private String name;
      private int age;
  
      public Person(String name, int age) {
          this.name = name;
          this.age = age;
      }
  
      public String getName() {
          return name;
      }
  
      public int getAge() {
          return age;
      }
  
      public void setName(String name) {
          this.name = name;
      }
  
      public void setAge(int age) {
          this.age = age;
      }
  
      @Override
      public String toString() {
          return "Person{" +
                  "name='" + name + '\'' +
                  ", age=" + age +
                  '}';
      }
  
      @Override
      public boolean equals(Object o) {
          System.out.println("equals方法");
          if (this == o) return true;
          if (o == null || getClass() != o.getClass()) return false;
          Person person = (Person) o;
          return age == person.age &&
                  Objects.equals(name, person.name);
      }
  
      @Override
      public int hashCode() {
          return Objects.hash(name, age);
      }
      //只比较年龄
      @Override
      public int compareTo(Object o) {
          if (this==o){
              return 0;
          }
          if (o instanceof Person){
              Person person= (Person) o;
              return this.age-person.age;
          }
          throw  new RuntimeException("类型不匹配");
      }
      //姓名和年龄都比较
  //    @Override
  //    public int compareTo(Object o) {
  //        if (this==o){
  //            return 0;
  //        }
  //        if (o instanceof Person){
  //            Person person= (Person) o;
  //            int value= this.age-person.age;
  //            if (value!=0){
  //                return value;
  //            }
  //            return -this.name.compareTo(person.name);
  //        }
  //        throw  new RuntimeException("类型不匹配");
  //    }
  }
  
  ```

  

##### Properties

```java
  @Test
    public void test1() throws IOException {
        File file=new File("info.properties");
        System.out.println(file.getAbsolutePath());
        FileInputStream inputStream=new FileInputStream(file);
        Properties properties=new Properties();
        properties.load(inputStream);
        //读取数据
        String name = properties.getProperty("name");
        String age = properties.getProperty("age");
        System.out.println("name="+name+"  age="+age);
    }
```

