#### String

* String类的声明

  * public final class String

      implements java.io.Serializable, Comparable<String>, CharSequence

  * 所以是不能继承的，因为有final

  * **String是引用数据类型，不能强转为基础数据类型**

  * 字符串只能与基础数据类型做+运算，返回的是String类型

  * 继承了Serializable，可以序列化的接口，凡是实现接口的类的对象就可以通过网络或者本地进行数据的传输

  * 继承Comparable：凡是实现这个类的都可以比较大小
  
  * 内部声明的属性
  
    * private final char value[]//真正存储数据库的容器，本质。
    * final代表是常量，修改相当于改变地址
    * jdk9就变成private final byte value[]
    *  / ==可以用来判断地址是否相同，equal判断内容
    * 字符串常量都存放在字符串常量池(StringTable)中
  * 字符串常量池不允许存放两个相同的字符串常量
    * 字符串常量池，在不同的jdk版本中，存放位置不同
    *  jdk7以前，存放在方法区，jdk7之后存放在堆中
  <img src="%E5%B8%B8%E7%94%A8%E7%B1%BB%E5%92%8CApi.assets/1690363318128.png" alt="1690363318128" style="zoom: 50%;" />![1690364335808](%E5%B8%B8%E7%94%A8%E7%B1%BB%E5%92%8CApi.assets/1690364335808.png)
  
  <img src="%E5%B8%B8%E7%94%A8%E7%B1%BB%E5%92%8CApi.assets/1690363318128.png" alt="1690363318128" style="zoom: 50%;" />![](%E5%B8%B8%E7%94%A8%E7%B1%BB%E5%92%8CApi.assets/1690364533067.png)

```java
  package Common;

import org.junit.Test;
public class test1 {
    @Test
    public void test(){
        String s1 = "hello";// 字面量的定义方式
        String s2 = "hello";
        System.out.println(s1 == s2);
        // ==可以用来判断地址是否相同
        // 字符串常量都存放在字符串常量池(StringTable)中
        // 字符串常量池不允许存放两个相同的字符串常量
        // 字符串常量池，在不同的jdk版本中，存放位置不同
        // jdk7以前，存放在方法区，jdk7之后存放在堆中
    }
    @Test
    public void test2(){
        String s1 = "hello";
        String s2 = "hello";
        s2="h1";
        System.out.println(s1);
    }
    @Test
    public void test3(){
        String s1 = "hello";
        String s2 = "hello";
        s2+="h1";//相加的要放到堆里
        System.out.println(s2);
    }
}

true
hello
helloh1

```

* 更改一次相当于重新开辟一个空间，相同的字符共用一个空间
* String的不可变性
  * 当对字符串变量重新赋值时，需要重新指定一个字符串常量的位置进行赋值，不能在原有的位置修改
  * 当对现有的字符串进行拼接操作时，需要重新开辟空间保存拼接以后的字符串，不能在原有的位置修改
  * 当调用字符串的replace()替换现有的某个字符时，需要重新开辟空间保存修改后的字符串

* String s3=new String("hello");内存解析

  <img src="%E5%B8%B8%E7%94%A8%E7%B1%BB%E5%92%8CApi.assets/1690366780350.png" alt="1690366780350" style="zoom:50%;" />
  * 所以String s3=new String("hello")相当于创建了两个对象，先new一个对象,new的这个地址再在常量池创建一个值，再指向过去。即一个堆空间，另外一个常量池

    ```java
    
    ```

  * <img src="%E5%B8%B8%E7%94%A8%E7%B1%BB%E5%92%8CApi.assets/1690367742225.png" alt="1690367742225" style="zoom: 80%;" />

  * 情况一：常量加常量：结果仍然存储在字符串常量池中

  * 情况二：常量加变量或变量+变量，都会通过new的方式创建一个新的字符串，返回堆空间字符串的地址

  * 使用intern()返回的是字符串常量池字面量的地址

    ```java
    @Test
        public void tes3t(){
            String s1 = "hello";// 字面量的定义方式
            String s2 = "world";
            String s3="helloworld";
            String s4="hello"+"world";//相当于helloworld
            String s5=s1+"world";//先用stringbuild append "hello"，再append world，最后再tostring,tostring方法的实现就是nwe了一个对象
            String s6="hello"+s2;
            String s7=s1+s2;
            System.out.println(s3==s4);//true
            System.out.println(s3==s5);//false
            System.out.println(s3==s6);//false
            System.out.println(s3==s7);//false
            System.out.println(s5==s6);//false
            System.out.println(s5==s7);//false
           
            String s8=s5.intern();//返回的是字符串常量池字面量的地址
            System.out.println(s3==s5);//true
            
        }
    ```

  * final修饰的字符串都是常量，final修饰的常量+变量/常量 ，结果为常量

    ```java
        @Test
        public void tes3t(){
            final String s1 = "hello";// 字面量的定义方式
            final String s2 = "world";
            String s3="helloworld";
            String s4="hello"+"world";//相当于helloworld
            String s5=s1+"world";//先用stringbuild append "hello"，再append world，最后再tostring,tostring方法的实现就是nwe了一个对象
            String s6="hello"+s2;
            String s7=s1+s2;
            System.out.println(s3==s5);//true
            System.out.println(s3==s6);//true
    
    
        }
    ```

    

  * concat()不管是常量还是变量，调用完以后都返回一个新new的对象

    ```java
        @Test
        public void tes3t(){
             String s1 = "hello";// 字面量的定义方式
            String s2 = "world";
            String s3=s1.concat(s2);
            String s4="hello".concat(s2);//相当于helloworld
            String s5=s1.concat("world");//先用stringbuild append "hello"，再append world，最后再tostring,tostring方法的实现就是nwe了一个对象
    
            System.out.println(s3==s4);//false
            System.out.println(s3==s5);//false
            System.out.println(s4==s5);//false
        }
    ```

* String 构造器

  * "public String()。初始化新创建的String对象。以使其表示空字符序列。

  * String(String original)'。初始化一个新创建的‘String’对象，使其表示一个与参数相同的字符序列。换句话说，"public string(char[] value)`。通过当前参数中的字符数组来构造新的String.`

  * `'public String(char[] valve,int offset，int count)`。通过字符数组的一部分来构造新的String。

  * 'public String(byte[] bytes)’。通过使用平台的*★默认字符集*★解码当前参数中的字节数组来构造新的String。

  * 'public String(byte[] bytes,String charsetName)’。通过使用指定的字符集解码当前参数中的字节数组来构造新的String

    ```java
    package Common;
    
    import org.junit.Test;
    public class test1 {
        @Test
        public void test(){
            String s1 = new String();
            String s2 = new String("");
            String s3=new String(new char[]{'a','b','c'});
            System.out.println(s3);
    
    
        }
        /*
        *String与常见类型的转换
         */
        @Test
        public void test2(){
            int num=10;
            //方式一
            String s1=num+"";
            //方式2
            String s2=String.valueOf(num);
    
            //String调用包装类
            String s3="123";
            int a=Integer.parseInt(s3);
        }
        //String与char[]转换
        @Test
        public void test3(){
            String str="hello";
            char[] arr=str.toCharArray();
            for (int i = 0; i < arr.length; i++) {
                System.out.println(arr[i]);
            }
            //二
            String str1=new String(arr);
            System.out.println(str1);
        }
        //String与byte[]转换
        //编码：String到01
        public void  test4(){
            String str=new String("hello");
            byte[] bytes=str.getBytes();
            for (int i = 0; i < bytes.length; i++) {
                System.out.println(bytes[i]);
            }
            String str1=new String(bytes);
            System.out.println(str1);
        }
    
    }
    
    
    ```

    

* 常用方法

  * 注意这个就行

    ```java
    @Test
        public void test(){
            String s1 ="";
            String s2 = new String();
            String s3 = new String("");
            //三个结果都是空，看源码返回的是数组的长度
            System.out.println(s1.isEmpty());
            System.out.println(s2.isEmpty());
            System.out.println(s3.isEmpty());
    
            String s4=null;
            //会报空指针异常
            System.out.println(s4.isEmpty());
    
        }
    ```

    

* **参数传递，基本数据型传递数据，引用数据型传递地址**

                 ````java
  package Common;
  
  import org.junit.Test;
  public class test1 {
      String str="good";
      char[] ch={'t','e','s','t'};
      public void change(String str,char ch[]){
          str="test ok";
          ch[0]='b';
      }
  
      public static void main(String[] args) {
          test1 t=new test1();
          t.change(t.str, t.ch);
          System.out.println(t.str);//good
          System.out.println(t.ch);//best
      }
  }
  
  
                 ````

  

* 三个类对比：String、StringBuffer、StringBuilder

  * String:不可变的字符序列（只能重新建一个，不可修改），jdk8之前底层使用char[]，9之后用byte[]
  * StringBuffer:可变的字符序列（可以在原位置上修改）jdk1.0声明，线程安全，效率低（有异步）jdk8之前底层使用char[]，9之后用byte[]
  * StringBuilder：可变的字符序列（可以在原位置上修改）jdk5.0声明，线程不安全，效率高jdk8之前底层使用char[]，9之后用byte[]

* StringBuffer、StringBuilder可变性分析

  * String s1=new String();//char value=new char[0];

  * String s1=new String();//char value=new char[]{‘a’,‘b’,‘c’};

  * StringBuilder内部属性有char[] value;//存储字符序列int count//实际存储字符的个数

    ```java
    //源码的初始化    
    public StringBuilder() {
            super(16);
    }
    public StringBuilder(String str) {
            super(str.length() + 16);
            append(str);
    }
    /*
    所以StringBuilder stringBuilder=new StringBuilder();等价于char[]value=new char[16]
    StringBuilder stringBuilder=new StringBuilder("abc");等价于char[]value=new char[16+"abc".length]
    **/
    //append实现
        private int newCapacity(int minCapacity) {
            // overflow-conscious code
            int newCapacity = (value.length << 1) + 2;
            if (newCapacity - minCapacity < 0) {
                newCapacity = minCapacity;
            }
            return (newCapacity <= 0 || MAX_ARRAY_SIZE - newCapacity < 0)
                ? hugeCapacity(minCapacity)
                : newCapacity;
        }
    
    //扩容为原来二倍加二，并把原有数据元素复制到新的数组中
    //最大长度private static final int MAX_ARRAY_SIZE = Integer.MAX_VALUE - 8;
    ```

    

* 总结：如果需要频繁的针对于字符串进行增删改查，建议StringBuffer、StringBuilder替换String,如果不考虑线程问题，就使用StringBuilder

* 如果开发中大体确定要操作字符串的个数，建议使用带int capacity参数的构造器，可以避免底层的多次扩容操作

* 面试题

  ```java
  public class test1 {
      public static void main(String[] args) {
          StringBuffer buffer=new StringBuffer("A");
          StringBuffer buffer2=new StringBuffer("B");
          opera(buffer,buffer2);
          System.out.println(buffer+"     "+buffer2);
      }
      public static void opera(StringBuffer buffer,StringBuffer buffer2){
          //引用类型传递地址，所以这两个参数是地址传递
          buffer.append(buffer2);//地址引用的值改了，此时外面的buffer也变为‘AB’
          buffer2=buffer;//buffer2也是AB,并且此时buffer2和buffer指向的地址一样，现在里面的buffer2和外面的buffer2的地址已经不一样了，里面变化不影响外面,外面还是B
          System.out.println(buffer2);
          buffer2.append(buffer);//相当于自己复制自己的值，变成了ABAB
      }
  }
  ABAB     B
  ```

  
  ```java
  package Common;
  
  import org.junit.Test;
  public class test1 {
      public static void main(String[] args) {
          String textString=new String("java");
          StringBuffer buffer2=new StringBuffer("java");
          stringReplace(textString);
          bufferReplace(buffer2);
          System.out.println(textString+"  "+buffer2);
  
      }
      public static void bufferReplace(StringBuffer buffer){
           buffer.append("c");//javac
           buffer=new StringBuffer("hello");//重新又赋了一个地址，和外面地址不同
           buffer.append("World");
      }
      public static void stringReplace(String text){
           text=text.replace("j","i");
      }
  }
  
  java  javac
  ```

  
  ```java
  package Common;
  
  import org.junit.Test;
  public class test1 {
      public static void main(String[] args) {
          String s="bbbb";
          StringBuffer buffer=new StringBuffer("aaaa");
          change(s,buffer);
          System.out.println(s+"  "+buffer);
  
  
      }
      public static void change(String s,StringBuffer buffer){
           s="aaaa";//值传递，与外面无关
           buffer.setLength(0);//引用传递，此时源码的count=0,相当于长度为0
           buffer.append("aaaa");//增加aaaa
      }
  
  }
  
  bbbb  aaaa
  ```

  
  ```java
  package Common;
  
  import org.junit.Test;
  public class test1 {
      public static void main(String[] args) {
          String str=null;
          StringBuffer buffer=new StringBuffer();
          buffer.append(str);
  
          System.out.println(buffer.length());
          System.out.println(buffer);
  
          StringBuffer buffer1=new StringBuffer(str);
          System.out.println(buffer1);
      }
  }
  4
  null
  空指针异常
  
  源码：    private AbstractStringBuilder appendNull() {
          int c = count;
          ensureCapacityInternal(c + 4);
          final char[] value = this.value;
          value[c++] = 'n';
          value[c++] = 'u';
          value[c++] = 'l';
          value[c++] = 'l';
          count = c;
          return this;
      }
  
      public StringBuffer(String str) {
          super(str.length() + 16);//在这里str.length()会报空指针异常
          append(str);
      }
  ```

  

* 所有难得就去看源码