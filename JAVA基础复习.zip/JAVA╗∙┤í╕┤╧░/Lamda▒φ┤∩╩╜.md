#### Lamda表达式

* 为什么要使用lambda表达式
  * 避免匿名内部类定义过多可以让你的代码看起来很简洁
  * 去掉了一堆没有意义的代码，只留下核心的逻辑。
* 函数式接口：只包含唯一一个抽象方法
  * 对于函数式接口，可以使用Lambda语法创建该接口对象

* 传统接口

  ```java
  //创建线程方式，一继承thread，二，重写run方法,三、调用start开启线程
  public class basic {
  
      public static void main(String[] args) throws InterruptedException, ExecutionException {
          Marry marry = new you();
          marry.HappyMarry();
  
      }
  
  }
  
  interface Marry {
      void HappyMarry();
  }
  
  class you implements Marry {
  
      @Override
      public void HappyMarry() {
          // TODO Auto-generated method stub
          System.out.println("结婚");
      }
  }
  
  ```

* 静态内部类方法

  ```java
  //创建线程方式，一继承thread，二，重写run方法,三、调用start开启线程
  public class basic {
      static class you implements Marry {
  
          @Override
          public void HappyMarry() {
              // TODO Auto-generated method stub
              System.out.println("结婚");
          }
      }
  
      public static void main(String[] args) throws InterruptedException, ExecutionException {
          Marry marry = new you();
          marry.HappyMarry();
  
      }
  
  }
  
  interface Marry {
      void HappyMarry();
  }
  
  ```

* 局部内部类

  ```java
  public class basic {
  
      public static void main(String[] args) throws InterruptedException, ExecutionException {
          class you implements Marry {
  
              @Override
              public void HappyMarry() {
                  // TODO Auto-generated method stub
                  System.out.println("结婚");
              }
          }
          Marry marry = new you();
          marry.HappyMarry();
  
      }
  
  }
  
  interface Marry {
      void HappyMarry();
  }
  ```

* 匿名内部类

  ```java
  public class basic {
  
      public static void main(String[] args) throws InterruptedException, ExecutionException {
          Marry marry = new Marry() {
  
              @Override
              public void HappyMarry() {
                  System.out.println("结婚");
              }
  
          };
          marry.HappyMarry();
  
      }
  
  }
  
  interface Marry {
      void HappyMarry();
  }
  
  ```

  

* lambda简化

  ```java
  public class basic {
  
      public static void main(String[] args) throws InterruptedException, ExecutionException {
          Marry marry = () -> {
              System.out.println("结婚");
          };
  
          marry.HappyMarry();
  
      }
  
  }
  
  interface Marry {
      void HappyMarry();
  }
  ```

  * 带参数的lanbda

    ```java
    public class basic {
    
        public static void main(String[] args) throws InterruptedException, ExecutionException {
            Marry marry = (int a) -> {
                System.out.println("结婚");
            };
    
            marry.HappyMarry(1);
    
        }
    
    }
    
    interface Marry {
        void HappyMarry(int a);
    }
    
    ```

    

  *  简化一：去掉参数的类型

  * 简化二：去掉括号

  * 简化三：省略花括号

    ```java
    public class basic {
    
        public static void main(String[] args) throws InterruptedException, ExecutionException {
            Marry marry = (int a) -> {
                System.out.println("结婚");
            };
            marry.HappyMarry(1);
            // 去掉参数类型
            Marry marry2 = (a) -> {
                System.out.println("aa");
            };
            marry2.HappyMarry(0);
            // 去掉参数括号
            Marry marry3 = a -> {
                System.out.println("aa");
            };
            marry3.HappyMarry(0);
            // 去掉花括号
            Marry marry4 = a -> System.out.println("aa");
            marry4.HappyMarry(0);
            // 总结，结构体只有一行才能省略代码体，即大括号
            // 必须是函数式接口
            // 多个参数也可以去掉参数类型，要去掉必须全去掉，多个参数括号不能省略
    
        }
    
    }
    
    interface Marry {
        void HappyMarry(int a);
    }
    
    ```

  